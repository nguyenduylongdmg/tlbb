/*
Navicat MySQL Data Transfer

Source Server         : #Localhost
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : web2

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2018-06-05 16:33:26
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `full_name` varchar(32) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `address` varchar(64) DEFAULT NULL,
  `password` char(32) NOT NULL,
  `password2` varchar(64) DEFAULT NULL,
  `question` varchar(64) DEFAULT NULL,
  `answer` varchar(64) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `qq` varchar(64) DEFAULT NULL,
  `tel` int(16) DEFAULT NULL,
  `profile_id` varchar(32) DEFAULT NULL,
  `profile_image_url` varchar(255) DEFAULT NULL,
  `id_type` enum('IdCard') DEFAULT 'IdCard',
  `id_card` varchar(32) DEFAULT NULL,
  `point` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(32) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`,`name`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('1', 'admin', 'GM', null, null, null, 'e10adc3949ba59abbe56e057f20f883e', 'e10adc3949ba59abbe56e057f20f883e', null, null, 'gm.tlsohu@gmail.com', null, '0', null, null, 'IdCard', null, '0', '::1', '0000-00-00 00:00:00', '2015-01-06 00:47:01');

-- ----------------------------
-- Table structure for card
-- ----------------------------
DROP TABLE IF EXISTS `card`;
CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accname` varchar(50) NOT NULL,
  `charguid` varchar(11) NOT NULL,
  `seri` varchar(20) NOT NULL,
  `code` varchar(20) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(20) NOT NULL,
  `khuyenmai` int(11) NOT NULL DEFAULT '0',
  `menhgia` int(11) NOT NULL DEFAULT '0',
  `loaithe` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `accname` (`accname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of card
-- ----------------------------

-- ----------------------------
-- Table structure for dos_ip
-- ----------------------------
DROP TABLE IF EXISTS `dos_ip`;
CREATE TABLE `dos_ip` (
  `ip` varchar(15) NOT NULL,
  `requested_on` int(10) unsigned NOT NULL,
  `request_uri` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  KEY `Index_1` (`ip`)
) ENGINE=MEMORY DEFAULT CHARSET=latin1 COMMENT='lưu ip request';

-- ----------------------------
-- Records of dos_ip
-- ----------------------------

-- ----------------------------
-- Table structure for dos_session
-- ----------------------------
DROP TABLE IF EXISTS `dos_session`;
CREATE TABLE `dos_session` (
  `session_id` varchar(45) NOT NULL,
  `requested_on` int(10) unsigned NOT NULL,
  `request_uri` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  KEY `Index_1` (`session_id`)
) ENGINE=MEMORY DEFAULT CHARSET=latin1 COMMENT='lưu thông tin session request';

-- ----------------------------
-- Records of dos_session
-- ----------------------------

-- ----------------------------
-- Table structure for gender
-- ----------------------------
DROP TABLE IF EXISTS `gender`;
CREATE TABLE `gender` (
  `id` int(11) NOT NULL DEFAULT '0',
  `sex` varchar(32) DEFAULT NULL,
  `active` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of gender
-- ----------------------------
INSERT INTO `gender` VALUES ('1', 'Nam', '1');
INSERT INTO `gender` VALUES ('2', 'Nữ', '1');

-- ----------------------------
-- Table structure for pay
-- ----------------------------
DROP TABLE IF EXISTS `pay`;
CREATE TABLE `pay` (
  `trade_no` varchar(20) NOT NULL,
  `channel` varchar(10) DEFAULT NULL,
  `server_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `fee` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `create_time` datetime NOT NULL,
  `pay_time` datetime DEFAULT NULL,
  PRIMARY KEY (`trade_no`),
  KEY `trade_no` (`trade_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pay
-- ----------------------------

-- ----------------------------
-- Table structure for security_questions
-- ----------------------------
DROP TABLE IF EXISTS `security_questions`;
CREATE TABLE `security_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) CHARACTER SET utf8 NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of security_questions
-- ----------------------------
INSERT INTO `security_questions` VALUES ('1', 'Cha của bạn sinh ra ở tỉnh/thành phố nào?', '1');
INSERT INTO `security_questions` VALUES ('2', 'Bạn thân nhất thời thơ ấu của bạn có họ gì?', '1');
INSERT INTO `security_questions` VALUES ('3', 'Tên trường tiểu học của bạn là gì?', '1');
INSERT INTO `security_questions` VALUES ('4', 'Con đường nơi bạn lớn lên tên gì?', '1');
INSERT INTO `security_questions` VALUES ('5', 'Con vật cưng đầu tiên của bạn tên gì?', '1');
INSERT INTO `security_questions` VALUES ('6', 'Tên của nhạc sĩ bạn thích nhất?', '1');
INSERT INTO `security_questions` VALUES ('7', 'Giáo viên bạn thích nhất khi học tiểu học có họ gì?', '1');
INSERT INTO `security_questions` VALUES ('8', 'Lúc nhỏ bạn thích xem phim hoạt hình nào nhất?', '1');
INSERT INTO `security_questions` VALUES ('9', 'Món khoái khẩu của bạn lúc còn nhỏ là gì?', '1');
INSERT INTO `security_questions` VALUES ('10', 'Nhân vật trong phim mà bạn thích nhất là ai?', '1');
INSERT INTO `security_questions` VALUES ('11', 'Ai là tác giả bạn thích nhất?', '1');
INSERT INTO `security_questions` VALUES ('12', 'Đội thể thao bạn thích nhất tên là gì?', '1');
INSERT INTO `security_questions` VALUES ('13', 'Tựa quyển sách bạn thích đọc nhất?', '1');

-- ----------------------------
-- Table structure for server
-- ----------------------------
DROP TABLE IF EXISTS `server`;
CREATE TABLE `server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `host` char(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of server
-- ----------------------------
INSERT INTO `server` VALUES ('1', 'Dragon Oath', '116.102.66.100');
